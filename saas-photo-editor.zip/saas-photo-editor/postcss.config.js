module.exports = {
    plugins: [
      require('tailwindcss'), // Tailwind CSS plugin
      require('autoprefixer'), // Add vendor prefixes
    ],
  }
  
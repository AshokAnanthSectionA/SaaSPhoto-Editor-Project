// src/components/Navbar.js
import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="bg-primary text-white py-4 px-6">
      <div className="max-w-screen-xl mx-auto flex justify-between items-center">
        <h2 className="font-bold text-2xl">SaaS Photo Editor</h2>
        <div className="space-x-4">
          <Link to="/" className="hover:text-lightSlateGray transition duration-300">
            Home
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
